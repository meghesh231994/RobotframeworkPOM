# name = "name:name"
# phone = "name:phone"
# email = "name:email"
# country = "name:country"
# city = "name:city"
# username = "xpath:(//input[@name='username'])[2]"
# password = "xpath:(//input[@name='password'])[2]"
# submitBtn = "xpath:(//*[@id='load_form']/div[1]/div[2]/input)[2]"

#Home Page Locators
newcar_xpath="//div[normalize-space()='NEW CARS']"
findnewcar_xpath="//div[contains(text(),'Find New Cars')]"




#Find New Car Page locators
newcar_header_xpath="//h1[normalize-space()='New Cars']"
toyotacar_xpath="//div[normalize-space()='Toyota']"
kiacar_xpath="//div[normalize-space()='Kia']"
bmwcar_xpath="//div[normalize-space()='BMW']"
maruticar_xpath="//div[normalize-space()='Maruti Suzuki']"
tatacar_xpath="//div[normalize-space()='Tata']"


#CarBase locators
carheading_xpath="//*[@id='root']/div[2]/div/div[2]/div/h1"
carnames_xpath="//div/div/div/a/h3"